#!/bin/bash
SRC="/home/snapchot/practica"
DEST="/var/backups/practica_backup/$(date +%F_%T)"
mkdir -p "$DEST"
rsync -av --delete "$SRC/" "$DEST/" >/var/log/backup_practica.log 2>&1
ln -sfn "$DEST" /var/backups/practica_backup/latest
