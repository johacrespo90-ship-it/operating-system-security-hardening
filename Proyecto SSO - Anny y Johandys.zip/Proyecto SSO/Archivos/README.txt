README — Instrucciones rápidas (de parte del docente)

Hola: abajo están las instrucciones básicas para preparar la VM y el checkpoint del Trabajo Final.

1) Punto de partida
- Usen la copia de Linux que ya tienen en sus máquinas. Deben partir de una VM limpia: sin configuraciones previas de prácticas anteriores.
- INMEDIATAMENTE antes de comenzar, creen un snapshot y nómbrenlo: base_practica_tf

2) Archivos que voy a subir y dónde están
- hashes.txt  -> Archivo con los hashes para la parte de password cracking (estará disponible para descargar desde la actividad en Moodle).
- base_practica_tf -> Snapshot / imagen base que deben importar o con el nombre que deben usar para el snapshot si crean la VM desde su ISO.

3) Reglas básicas
- Trabajar siempre sobre una copia del snapshot/base_practica_tf. Si algo falla, restauren el snapshot.
- Toda la práctica se hace dentro de la VM. No atacar sistemas externos ni usar recursos fuera de la VM.
- No modificar el snapshot base original; crear y trabajar sobre una copia.

4) Entrega final
- Subir un único .zip por grupo con: informe PDF + carpeta de evidencias + README con instrucciones para reproducir los pasos (desde el snapshot que entregaron).

Si tienen problemas técnicos con la importación o creación del snapshot...que la Fuerza los acompañe
Saludos